#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
  int fm = settickets(20);
  printf(1,"%d\n",fm);
  exit();
}
